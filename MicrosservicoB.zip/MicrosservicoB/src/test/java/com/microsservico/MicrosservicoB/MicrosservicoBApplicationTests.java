package com.microsservico.MicrosservicoB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicrosservicoBApplicationTests {

	@Test
	void contextLoads() {
	}

}
