package com.microsservico.MicrosservicoB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class MicrosservicoBApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicrosservicoBApplication.class, args);
	}

}
