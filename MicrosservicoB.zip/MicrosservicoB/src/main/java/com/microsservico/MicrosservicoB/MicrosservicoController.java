package com.microsservico.MicrosservicoB;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

@RestController
public class MicrosservicoController {

    static String webService = "http://api.worldbank.org/v2/country/";
    static int codigoSucesso = 200;
    //static String id = "al";

    public static String buscaPais(String id) throws Exception {
        String urlParaChamada = webService + id + "/indicator/SI.POV.DDAY?format=json";

        try {
            URL url = new URL(urlParaChamada);
            HttpURLConnection conexao = (HttpURLConnection) url.openConnection();

            if (conexao.getResponseCode() != codigoSucesso)
                throw new RuntimeException("HTTP error code : " + conexao.getResponseCode());

            BufferedReader resposta = new BufferedReader(new InputStreamReader((conexao.getInputStream())));
            String jsonEmString = Formatar.converteJsonEmString(resposta);

            return jsonEmString;
        } catch (Exception e) {
            throw new Exception("ERRO: " + e);
        }
    }

    @GetMapping("/dados-pais")
    @ResponseBody
    public String dadosPais() throws Exception {
        return buscaPais("al");
    }

}
