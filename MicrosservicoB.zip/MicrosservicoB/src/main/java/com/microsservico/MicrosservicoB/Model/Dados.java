package com.microsservico.MicrosservicoB.Model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Dados {
    private String indicator, country, countryiso3code, date, value, unit, obs_status, decimal;

    public Dados() {
    }

    public String getIndicator() {
        return indicator;
    }

    public void setIndicator(String indicator) {
        this.indicator = indicator;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCountryiso3code() {
        return countryiso3code;
    }

    public void setCountryiso3code(String countryiso3code) {
        this.countryiso3code = countryiso3code;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getObs_status() {
        return obs_status;
    }

    public void setObs_status(String obs_status) {
        this.obs_status = obs_status;
    }

    public String getDecimal() {
        return decimal;
    }

    public void setDecimal(String decimal) {
        this.decimal = decimal;
    }

    @Override
    public String toString() {
        return "Dados{" +
                "indicator='" + indicator + '\'' +
                ", country='" + country + '\'' +
                ", countryiso3code='" + countryiso3code + '\'' +
                ", date='" + date + '\'' +
                ", value='" + value + '\'' +
                ", unit='" + unit + '\'' +
                ", obs_status='" + obs_status + '\'' +
                ", decimal='" + decimal + '\'' +
                '}';
    }
}
